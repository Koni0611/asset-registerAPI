package com.asset_register.assert_register;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssertRegisterApplicationTests {

	@Test
	void contextLoads() {
	}

}
